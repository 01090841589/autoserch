module.exports = {
  "transpileDependencies": [
    "vuetify"
  ]
}