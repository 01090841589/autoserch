export default {
  checkLogin(context) {
    context.commit("checkLogin");
  },
};
